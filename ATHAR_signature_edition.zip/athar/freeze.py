"""Render the Flask app to static files in dist/ for deployment on Netlify.

Netlify serves static files and does not run a long-lived Python server,
so every page is rendered once at build time through Flask's test client.
"""
import shutil
from pathlib import Path

from app import app, INITIATIVES, PROJECT_DIR, build_project_zip

OUT = PROJECT_DIR / "dist"

PAGES = ["/", "/about", "/founder", "/propose", "/propose/thanks", "/download"]
PAGES += [f"/initiative/{x['id']}" for x in INITIATIVES]


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def main():
    shutil.rmtree(OUT, ignore_errors=True)
    client = app.test_client()
    for page in PAGES:
        res = client.get(page)
        assert res.status_code == 200, f"{page} returned {res.status_code}"
        target = OUT / page.strip("/") / "index.html"
        write(target, res.data)
        print("rendered", page)

    res = client.get("/initiative/0")
    write(OUT / "404.html", res.data)

    shutil.copytree(PROJECT_DIR / "static", OUT / "static")
    write(OUT / "athar-project.zip", build_project_zip())
    print("done ->", OUT)


if __name__ == "__main__":
    main()
