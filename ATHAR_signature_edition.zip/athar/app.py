import os, sqlite3, secrets, hmac
from pathlib import Path
from datetime import date
from flask import Flask, render_template, request, redirect, url_for, flash, session, abort

app = Flask(__name__)
app.config.update(SECRET_KEY=os.environ.get('ATHAR_SECRET_KEY', 'local-development-key-change-before-deploy'), SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
DB_PATH = Path(os.environ.get('ATHAR_DB_PATH', str(Path(__file__).resolve().parent / 'instance' / 'athar.db')))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
CATEGORIES = ['تضامني','تبرعات عينية','بيئي','صحي','تعليمي','اجتماعي','مهارات','تطوعي']

def db():
    con=sqlite3.connect(DB_PATH); con.row_factory=sqlite3.Row; return con

def init_db():
    with db() as con:
        con.execute("CREATE TABLE IF NOT EXISTS initiatives (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, category TEXT NOT NULL, city TEXT NOT NULL, date TEXT NOT NULL, end_date TEXT, organizer TEXT NOT NULL, contact TEXT, spots INTEGER NOT NULL DEFAULT 0, description TEXT NOT NULL, published INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)")
        if con.execute('SELECT COUNT(*) FROM initiatives').fetchone()[0] == 0:
            samples=[('حملة تشجير الحي','بيئي','الجزائر العاصمة','2026-11-07','','فريق أثر','',12,'نموذج توضيحي. لا يُعد الموعد مؤكدًا إلا بعد تنسيق الجهة المنظمة.',0),('جمع الكتب والملابس بحالة جيدة','تبرعات عينية','تيبازة','2026-11-15','','فريق أثر','',8,'نموذج توضيحي لحملة جمع تبرعات عينية. تُنشر الحملات الفعلية بعد التحقق من الجهة ومكان التسليم.',0)]
            con.executemany('INSERT INTO initiatives (title,category,city,date,end_date,organizer,contact,spots,description,published) VALUES (?,?,?,?,?,?,?,?,?,?)',samples)

def csrf_token():
    if 'csrf_token' not in session: session['csrf_token']=secrets.token_urlsafe(24)
    return session['csrf_token']
app.jinja_env.globals['csrf_token']=csrf_token

@app.before_request
def protect_post():
    if request.method == 'POST':
        supplied=request.form.get('csrf_token',''); expected=session.get('csrf_token','')
        if not supplied or not expected or not hmac.compare_digest(supplied,expected): abort(400, 'طلب غير صالح. أعد تحميل الصفحة وحاول مجددًا.')

@app.context_processor
def shared_context(): return {'founder_name':'يسرى سديرة'}

@app.route('/')
def home():
    q=request.args.get('q','').strip().casefold(); category=request.args.get('category','').strip(); city=request.args.get('city','').strip()
    with db() as con: rows=con.execute('SELECT * FROM initiatives WHERE published=1 ORDER BY date ASC, id DESC').fetchall()
    items=[dict(x) for x in rows]
    if q: items=[x for x in items if q in (x['title']+' '+x['description']+' '+x['organizer']+' '+x['city']).casefold()]
    if category: items=[x for x in items if x['category']==category]
    if city: items=[x for x in items if x['city']==city]
    return render_template('index.html',initiatives=items,categories=sorted({x['category'] for x in rows}),cities=sorted({x['city'] for x in rows}),q=q,selected_category=category,selected_city=city)

@app.route('/initiative/<int:initiative_id>')
def initiative_detail(initiative_id):
    with db() as con: row=con.execute('SELECT * FROM initiatives WHERE id=? AND published=1',(initiative_id,)).fetchone()
    if row is None: return render_template('not_found.html'),404
    return render_template('initiative.html',item=dict(row))

@app.route('/propose',methods=['GET','POST'])
def propose():
    if request.method=='POST':
        title=request.form.get('title','').strip(); organizer=request.form.get('organizer','').strip(); details=request.form.get('details','').strip()
        if not title or not organizer or not details: flash('يرجى ملء الحقول المطلوبة.','error')
        else:
            with db() as con: con.execute('INSERT INTO initiatives (title,category,city,date,organizer,spots,description,published) VALUES (?,?,?,?,?,?,?,0)',(title,request.form.get('category','تضامني'),request.form.get('city','لم تحدد'),request.form.get('date') or date.today().isoformat(),organizer,0,details))
            flash('وصل اقتراحك إلى قائمة المراجعة، ولن يظهر للعموم قبل موافقة الإدارة.','success'); return redirect(url_for('propose'))
    return render_template('propose.html')

@app.route('/about')
def about(): return render_template('about.html')
@app.route('/founder')
def founder(): return render_template('founder.html')
@app.route('/download')
def download(): return render_template('download.html')

@app.route('/admin',methods=['GET','POST'])
def admin_login():
    if session.get('admin'): return redirect(url_for('admin_dashboard'))
    if request.method=='POST':
        username=os.environ.get('ATHAR_ADMIN_USERNAME',''); password=os.environ.get('ATHAR_ADMIN_PASSWORD','')
        if not username or not password or not os.environ.get('ATHAR_SECRET_KEY'): flash('الإدارة غير مهيأة بعد. اضبطي بيانات الإدارة ومفتاح الأمان في إعدادات الاستضافة.','error')
        elif hmac.compare_digest(request.form.get('username',''),username) and hmac.compare_digest(request.form.get('password',''),password):
            session.clear(); session['admin']=True; session['csrf_token']=secrets.token_urlsafe(24); return redirect(url_for('admin_dashboard'))
        else: flash('اسم المستخدم أو كلمة المرور غير صحيحة.','error')
    return render_template('admin_login.html')

def require_admin():
    if not session.get('admin'): return redirect(url_for('admin_login'))
    return None

@app.route('/admin/dashboard')
def admin_dashboard():
    guard=require_admin()
    if guard: return guard
    with db() as con: items=[dict(x) for x in con.execute('SELECT * FROM initiatives ORDER BY created_at DESC,id DESC').fetchall()]
    return render_template('admin.html',items=items)

@app.route('/admin/add',methods=['POST'])
def admin_add():
    guard=require_admin()
    if guard: return guard
    title=request.form.get('title','').strip(); city=request.form.get('city','').strip(); organizer=request.form.get('organizer','').strip(); desc=request.form.get('description','').strip(); start=request.form.get('date','').strip(); end=request.form.get('end_date','').strip()
    if not all([title,city,organizer,desc,start]): flash('يرجى ملء الحقول الأساسية.','error')
    elif end and end < start: flash('تاريخ النهاية يجب أن يكون في يوم البداية أو بعده.','error')
    else:
        try: spots=max(0,min(100000,int(request.form.get('spots','0') or 0)))
        except ValueError: spots=0
        with db() as con: con.execute('INSERT INTO initiatives (title,category,city,date,end_date,organizer,contact,spots,description,published) VALUES (?,?,?,?,?,?,?,?,?,?)',(title,request.form.get('category','تطوعي'),city,start,end,organizer,request.form.get('contact','').strip(),spots,desc,1 if request.form.get('published')=='yes' else 0))
        flash('تم حفظ المبادرة بنجاح.','success')
    return redirect(url_for('admin_dashboard'))

@app.route('/admin/<int:initiative_id>/toggle',methods=['POST'])
def admin_toggle(initiative_id):
    guard=require_admin()
    if guard: return guard
    with db() as con: con.execute('UPDATE initiatives SET published=CASE published WHEN 1 THEN 0 ELSE 1 END WHERE id=?',(initiative_id,))
    flash('تم تحديث حالة النشر.','success'); return redirect(url_for('admin_dashboard'))

@app.route('/admin/<int:initiative_id>/delete',methods=['POST'])
def admin_delete(initiative_id):
    guard=require_admin()
    if guard: return guard
    with db() as con: con.execute('DELETE FROM initiatives WHERE id=?',(initiative_id,))
    flash('تم حذف المبادرة.','success'); return redirect(url_for('admin_dashboard'))

@app.route('/admin/logout',methods=['POST'])
def admin_logout():
    session.clear(); flash('تم تسجيل الخروج.','success'); return redirect(url_for('home'))

init_db()
if __name__=='__main__': app.run(host='127.0.0.1',port=int(os.environ.get('PORT','5000')),debug=False)
